from flask import Flask, render_template, request, redirect,send_from_directory,send_file
import pymysql
import logging
from io import BytesIO
import os
from PIL import Image, ImageDraw, ImageFont
mysqldb = pymysql.connect(host='localhost', db='login', user='root', password='642642', charset='utf8')
cur = mysqldb.cursor()
# 引入file_dict用户列表


app = Flask(__name__)
app.logger.setLevel(logging.ERROR)
app.config['UPLOAD_FOLDER'] = 'static/images'  # 假设图片存储在静态文件夹下的images子文件夹中
app.config['UPLOAD_FOLDER'] = 'static/uploads'

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/loginaction/', methods=["POST", "GET"])
def login():
    error_msg = ''
    if request.method == 'GET':
        username = request.args.get('username')
        password = request.args.get('password')
    else:
        username = request.form.get('username')
        password = request.form.get('password')

    print('username:%s,password:%s' % (username, password))

    if username and password:
        if username == "admin" and password == "admin":
            return redirect('/ht')
        else:
            error_msg = "用户名或密码是错误的"
    else:
        error_msg = "需要用户名或密码"

    return render_template('login.html', error_msg=error_msg)

@app.route('/list/')
def userlist():
    sql = "select * from content"
    cur.execute(sql)
    userlist = cur.fetchall()
    return render_template('list.html', userlist=userlist)

@app.route('/dt/')
def dt():
    sql = "select * from content"
    cur.execute(sql)
    userlist = cur.fetchall()
    return render_template('dt.html', userlist=userlist)

@app.route('/make/')
def make():
    return render_template('make.html')

@app.route('/update/')
def update():
    name = request.args.get('name')
    sql = "select * from content where name = %s"
    cur.execute(sql, (name,))
    user = [name]
    return render_template('update.html', user=user)



@app.route('/updateaction/', methods=['POST'])
def updateaction():
    params = request.args if request.method == 'GET' else request.form

    theme = params.get('theme')
    word = params.get('word')
    time = params.get('time')
    location = params.get('location')
    name = params.get('name')

    sql = "update content set theme=%s,word=%s,time=%s,location=%s where name = %s"
    cur.execute(sql, (theme,word,time,location,name))
    mysqldb.commit()

    return redirect('/list/')



@app.route('/add/')
def add():
    return render_template('add.html')


@app.route('/addaction/', methods=['POST'])
def addaction():
    params = request.args if request.method == 'GET' else request.form
    name = params.get('name')
    theme = params.get('theme')
    word = params.get('word')
    time = params.get('time')
    location = params.get('location')

    sql = "insert into content (name,theme,word,time,location) values (%s,%s,%s,%s,%s)"
    cur.execute(sql, (name,theme,word,time,location))
    mysqldb.commit()
    return redirect('/list/')


@app.route('/delete/')
def delete():
    name = request.args.get('name')
    # sql = "insert into t_user(name,age) values('%s',%d)"%('eric',30)
    sql = "DELETE from content where name = %s"
    # sql = "update t_user set name ='%s' where id=%d" % ("张三", 1)
    cur.execute(sql,(name,))
    mysqldb.commit()

    return redirect('/dt/')

@app.route('/ht/')
def ht():
    return render_template("HT03.html")


@app.route('/show_image/<image_name>')
def show_image(image_name):
    # 检查图片名称是否安全，防止路径遍历攻击
    if not image_name.replace('.', '', 1).isalnum():
        return 'Invalid image name', 400

        # 渲染包含图片的模板
    return render_template('show_image.html', image_name=image_name)


# 如果需要直接访问图片，可以添加以下路由
@app.route('/static/images/<path:filename>')
def serve_image(filename):
    return send_from_directory('static/images', filename)


image_index = {
    1: '1.jpg',
    2: '2.jpg',
    3: '3.jpg',
    4: '4.jpg',
    5: '5.jpg',
    6: '6.jpg',
    7: '7.jpg',
    8: '8.jpg',
    9: '9.jpg',
    10: '10.jpg',
    11: '11.jpg',
    12: '12.jpg',
    13: '13.jpg',
    14: '14.jpg',
    15: '15.jpg',
    16: '16.jpg',
    17: '17.jpg',
    18: '18.jpg',
    19: '19.jpg',
    20: '20.jpg'
}


# 视图函数：搜索图片
@app.route('/search', methods=['GET'])
def search():
    number = request.args.get('q')  # 从查询参数中获取数字
    if number and number.isdigit() and int(number) in image_index:
        # 获取图片文件名
        image_name = image_index[int(number)]
        # 构造图片文件的完整路径
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_name)

        # 检查文件是否存在
        if os.path.isfile(image_path):
            # 返回图片文件
            return send_from_directory(app.config['UPLOAD_FOLDER'], image_name, as_attachment=True)
        else:
            # 如果文件不存在，返回错误消息
            return "Image not found", 404
    else:
        # 如果输入无效或不存在，返回错误消息
        return "Invalid number or number not found.", 400

@app.route('/tupian')
def show_images():
    return render_template('index.html')

@app.route('/make_invitation')
def make_invitation():
    try:
        params = request.args if request.method == 'GET' else request.form

        change_name = request.args.get('name')
        query = "SELECT name, theme, word, time, location FROM content WHERE name = %s"
        cur.execute(query, (change_name,))

        # 从查询结果中获取数据
        invitation_data = cur.fetchone()
        if not invitation_data:
            return "No invitation data found", 404
        name, theme, word, time, location = invitation_data

        # 打开原始图像
        current_dir = os.path.dirname(os.path.abspath(__file__))
        picture_dir = os.path.join(current_dir, "static", "images")
        chose_dir = os.path.join(picture_dir, "10.jpg")
        image = Image.open(chose_dir)

        # 获取图像宽高
        image_width, image_height = image.size

        # 创建绘图对象
        draw = ImageDraw.Draw(image)

        # 加载字体
        font_theme = ImageFont.truetype("simsun.ttc", 48, encoding="utf-8")
        font_name = ImageFont.truetype("simsun.ttc", 36, encoding="utf-8")
        font_word = ImageFont.truetype("simsun.ttc", 30, encoding="utf-8")
        font_time_loc = ImageFont.truetype("simsun.ttc", 24, encoding="utf-8")

        # 设置文字相对位置,取值0-1
        themerel_x = 0.5
        themerel_y = 0.2

        namerel_x = 0.2
        namerel_y = 0.3

        wordrel_x = 0.1
        wordrel_y = 0.4

        timerel_x = 0.7
        timerel_y = 0.7

        locationrel_x = 0.7
        locationrel_y = 0.8

        # 计算文字大小
        theme_width, theme_height = font_theme.getlength(theme), font_theme.size
        name_width, name_height = font_name.getlength(name), font_name.size
        word_width, word_height = font_word.getlength(word), font_word.size
        time_width, time_height = font_time_loc.getlength(time), font_time_loc.size
        location_width, location_height = font_time_loc.getlength(location), font_time_loc.size

        # 计算文字起始坐标
        themetext_x = int((image_width - theme_width) * themerel_x)
        themetext_y = int((image_height - theme_height) * themerel_y)

        nametext_x = int((image_width - name_width) * namerel_x)
        nametext_y = int((image_height - name_height) * namerel_y)

        wordtext_x = int((image_width - word_width) * wordrel_x)
        wordtext_y = int((image_height - word_height) * wordrel_y)

        timetext_x = int((image_width - time_width) * timerel_x)
        timetext_y = int((image_height - time_height) * timerel_y)

        locationtext_x = int((image_width - location_width) * locationrel_x)
        locationtext_y = int((image_height - location_height) * locationrel_y)

        # 在图像上绘制文本,使用不同的字体大小和样式
        # 主题
        draw.text((themetext_x - 2, themetext_y - 2), theme, font=font_theme, fill=(0, 0, 0))
        draw.text((themetext_x, themetext_y), theme, font=font_theme, fill=(255, 255, 255))

        # 姓名
        draw.text((nametext_x - 2, nametext_y - 2), name, font=font_name, fill=(0, 0, 0))
        draw.text((nametext_x, nametext_y), name, font=font_name, fill=(255, 255, 0))

        # 祝词
        draw.text((wordtext_x - 2, wordtext_y - 2), word, font=font_word, fill=(0, 0, 0))
        draw.text((wordtext_x, wordtext_y), word, font=font_word, fill=(255, 255, 255))

        # 时间
        draw.text((timetext_x - 2, timetext_y - 2), time, font=font_time_loc, fill=(0, 0, 0))
        draw.text((timetext_x, timetext_y), time, font=font_time_loc, fill=(255, 255, 255))

        # 地点
        draw.text((locationtext_x - 2, locationtext_y - 2), location, font=font_time_loc, fill=(0, 0, 0))
        draw.text((locationtext_x, locationtext_y), location, font=font_time_loc, fill=(255, 255, 255))

        # 保存图片
        filename = '1.jpg'
        output_dir = os.path.join(current_dir, 'static', 'output')
        output_path = os.path.join(output_dir, filename)
        os.makedirs(output_dir, exist_ok=True)
        image.save(output_path)

        img_io = BytesIO()
        image.save(img_io, 'JPEG')
        img_io.seek(0)

        return send_file(img_io, mimetype='image/jpeg')
    except Exception as e:
        app.logger.error(f"Error occurred: {e}")
        return "An error occurred", 500

# routes.py
@app.route('/choose_background', methods=['GET', 'POST'])
def choose_background():
    if request.method == 'POST':
        # 处理用户选择的背景图片
        background_image = request.form.get('background_image')
        # 将背景图片信息存储在会话中
        session['background_image'] = background_image
        return redirect(url_for('canvas'))
    else:
        # 获取可用的背景图片列表
        background_images = os.listdir(os.path.join(app.static_folder, 'images'))
        return render_template('choose_background.html', background_images=background_images)

# routes.py
@app.route('/canvas', methods=['GET', 'POST'])
def canvas():
    if 'background_image' not in session:
        return redirect(url_for('choose_background'))

    background_image = session['background_image']

    if request.method == 'POST':
        # 处理用户在Canvas上的操作,如更改文字位置、大小等
        pass

    # 从MySQL中读取数据
    query = "SELECT name, theme, word, time, location FROM content WHERE name = %s"
    cur.execute(query, (current_user.username,))
    invitation_data = cur.fetchone()

    if not invitation_data:
        flash('未找到邀请函数据', 'error')
        return redirect(url_for('index'))

    name, theme, word, time, location = invitation_data

    return render_template('canvas.html', background_image=background_image, name=name, theme=theme, word=word, time=time, location=location)


if __name__ == "__main__":
    app.run(host='127.0.0.1', debug=True)
