# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont
import os
import pymysql
mysqldb = pymysql.connect(host='127.0.0.1', db='login', user='root', password='642642', charset='utf8')
cur = mysqldb.cursor()

class Invitation:
    def __init__(self, name, theme, word, time, location):
        self.__name = name
        self.__theme = theme
        self.__word = word
        self.__time = time
        self.__location = location

    def get_name(self):
        return self.__name

    def get_theme(self):
        return self.__theme

    def get_word(self):
        return self.__word

    def get_time(self):
        return self.__time

    def get_location(self):
        return self.__location

# 执行查询以获取邀请详情
cur.execute("SELECT name, theme, word, time, location FROM content WHERE name = %s",("cyy",))

# 从查询结果中获取数据
invitation_data = cur.fetchone()

# 使用获取的数据创建Invitation对象
inv = Invitation(*invitation_data)

# 打开原始图像
image = Image.open("C:\\Users\\10142\\Desktop\\背景\\11.jpg")

# 获取图像宽高
image_width, image_height = image.size

# 创建绘图对象
draw = ImageDraw.Draw(image)

# 加载字体
# 创建字体对象
font_theme = ImageFont.truetype("simsun.ttc", 48, encoding="utf-8")
font_name = ImageFont.truetype("simsun.ttc", 36, encoding="utf-8")
font_word = ImageFont.truetype("simsun.ttc", 30, encoding="utf-8")
font_time_loc = ImageFont.truetype("simsun.ttc", 24, encoding="utf-8")

# 设置文字相对位置,取值0-1
themerel_x = 0.5
themerel_y = 0.2

namerel_x = 0.2
namerel_y = 0.3

wordrel_x = 0.1
wordrel_y = 0.4

timerel_x = 0.7
timerel_y = 0.7

locationrel_x = 0.7
locationrel_y = 0.8

# 计算文字起始坐标
theme_width, theme_height = draw.textsize(inv.get_theme(), font=font_theme)
themetext_x = int((image_width - theme_width) * themerel_x)
themetext_y = int((image_height - theme_height) * themerel_y)

name_width, name_height = draw.textsize(inv.get_name(), font=font_name)
nametext_x = int((image_width - name_width) * namerel_x)
nametext_y = int((image_height - name_height) * namerel_y)

word_width, word_height = draw.textsize(inv.get_word(), font=font_word)
wordtext_x = int((image_width - word_width) * wordrel_x)
wordtext_y = int((image_height - word_height) * wordrel_y)

time_width, time_height = draw.textsize(inv.get_time(), font=font_time_loc)
timetext_x = int((image_width - time_width) * timerel_x)
timetext_y = int((image_height - time_height) * timerel_y)

location_width, location_height = draw.textsize(inv.get_location(), font=font_time_loc)
locationtext_x = int((image_width - location_width) * locationrel_x)
locationtext_y = int((image_height - location_height) * locationrel_y)



# 在图像上绘制文本,使用不同的字体大小和样式
# 主题
draw.text((themetext_x-2, themetext_y-2), inv.get_theme(), font=font_theme, fill=(0, 0, 0))
draw.text((themetext_x, themetext_y), inv.get_theme(), font=font_theme, fill=(255, 255, 255))

# 姓名
draw.text((nametext_x-2, nametext_y-2), inv.get_name(), font=font_name, fill=(0, 0, 0))
draw.text((nametext_x, nametext_y), inv.get_name(), font=font_name, fill=(255, 255, 0))

# 祝词
draw.text((wordtext_x-2, wordtext_y-2), inv.get_word(), font=font_word, fill=(0, 0, 0))
draw.text((wordtext_x, wordtext_y), inv.get_word(), font=font_word, fill=(255, 255, 255))

# 时间
draw.text((timetext_x-2, timetext_y-2), inv.get_time(), font=font_time_loc, fill=(0, 0, 0))
draw.text((timetext_x, timetext_y), inv.get_time(), font=font_time_loc, fill=(255, 255, 255))

# 地点
draw.text((locationtext_x-2, locationtext_y-2), inv.get_location(), font=font_time_loc, fill=(0, 0, 0))
draw.text((locationtext_x, locationtext_y), inv.get_location(), font=font_time_loc, fill=(255, 255, 255))
# 保存图片
filename = '1.jpg'
output_dir = "C:\\Users\\10142\\Desktop\\输出"
output_path = os.path.join(output_dir, filename)
os.makedirs(output_dir, exist_ok=True)
image.save(output_path)
